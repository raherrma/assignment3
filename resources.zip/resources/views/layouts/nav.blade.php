<header id="main-header" class="p-5 text-center">

    <h1>freeSTUFF!</h1>
    <p id="tag-line" class="pt-2">
        get awsome stuff for free
    </p>

    <nav class="navbar navbar-expand-lg pt-5">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample10" aria-controls="navbarsExample10" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample10">

            <ul class="navbar-nav">

                <li class="nav-item px-3 text-uppercase">
                    <a class="nav-link" href="#">Link</a>
                </li>

                <li class="nav-item px-3 text-uppercase">
                    <a class="nav-link" href="#">Link</a>
                </li>

                <li class="nav-item px-3 text-uppercase">
                    <a class="nav-link" href="#">Link</a>
                </li>

                <li class="nav-item dropdown px-3 text-uppercase">
                    <a class="nav-link dropdown-toggle" href="https://example.com" id="dropdown10" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                    <div class="dropdown-menu bg-dark" aria-labelledby="dropdown10">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </li>

            </ul>

        </div>

    </nav>

</header>