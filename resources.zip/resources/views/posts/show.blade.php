@extends ('layouts.master')

@section ('content')

    <article class="row bg-light">

        <header id="item-header" class="col-12 p-3">

            <h1>Descriptive Item title</h1>

            <div class="item-meta">
                <p class="mb-0">
                    <span class="font-weight-bold">Giver:</span> Name Namesen | <span class="font-weight-bold">Category:</span> Cat-Name | <span class="font-weight-bold">Published:</span> 01-01-2018
                </p>
            </div>


        </header>

        <section id="item-content" class="col-12 pt-2">

            <h2>Description</h2>

            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>

        </section>

    </article>

@endsection